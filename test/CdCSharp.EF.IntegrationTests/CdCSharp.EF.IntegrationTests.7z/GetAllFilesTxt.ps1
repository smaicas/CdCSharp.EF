# Ruta del archivo de salida
$outputFile = "ListadoArchivosCS.txt"

# Carpetas a excluir (por defecto incluye bin y obj)
$excludedDirs = @("bin", "obj")

# Puedes agregar más carpetas a excluir aquí si deseas
# $excludedDirs += "carpetaPersonalizada"

# Limpiar el archivo de salida si ya existe
if (Test-Path $outputFile) {
    Remove-Item $outputFile
}

# Obtener todos los archivos .cs, excluyendo los que están dentro de las carpetas excluidas
$csFiles = Get-ChildItem -Path . -Recurse -Filter *.cs -File | Where-Object {
    $relativePath = $_.FullName.Replace((Get-Location).Path + "\", "")
    foreach ($excluded in $excludedDirs) {
        if ($relativePath -match "[\\\/]$excluded[\\\/]") {
            return $false
        }
    }
    return $true
}

foreach ($file in $csFiles) {
    # Obtener la ruta relativa
    $relativePath = $file.FullName.Replace((Get-Location).Path + "\", "")

    # Escribir la ruta relativa al archivo de salida
    Add-Content -Path $outputFile -Value "=== $relativePath ==="
    Add-Content -Path $outputFile -Value ""

    # Escribir el contenido del archivo
    Get-Content -Path $file.FullName | Add-Content -Path $outputFile

    # Separador entre archivos
    Add-Content -Path $outputFile -Value "`n`n"
}